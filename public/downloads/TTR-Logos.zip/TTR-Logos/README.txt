TTR logos

Light: Ash logo for Obsidian and dark grounds.
Dark: Obsidian logo for Ash and light grounds.
Gold: Golden Yellow. Reserved, dark grounds only.

SVG for anything that scales. PNG (4000px) for slides and docs.
Keep half the symbol's width clear on every side. Symbol: 24px minimum.
Full guide: https://ttbrand.vercel.app
