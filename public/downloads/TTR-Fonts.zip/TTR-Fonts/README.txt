TTR fonts

Trove Super Condensed: headlines and display. Uppercase only.
Druk Condensed Super: licensed. Use only under Treasure Trove's license.
Web/: Trove as WOFF2 for websites.
Archivo (free): body copy, UI, captions. https://fonts.google.com/specimen/Archivo
Anton (free): fallback for Trove in Google Slides and shared docs. https://fonts.google.com/specimen/Anton
